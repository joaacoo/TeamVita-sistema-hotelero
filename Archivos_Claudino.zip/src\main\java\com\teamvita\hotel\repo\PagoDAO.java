package com.teamvita.hotel.repo;
import com.teamvita.hotel.model.*;
import java.util.List;

public class PagoDAO {
    public void registrarPago(Pago pago) {}
}
