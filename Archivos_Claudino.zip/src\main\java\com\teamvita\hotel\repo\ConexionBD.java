package com.teamvita.hotel.repo;
import java.sql.Connection;

public class ConexionBD {
    private static ConexionBD instancia;
    private ConexionBD() {}
    public static ConexionBD getInstancia() { return null; }
    public Connection getConnection() { return null; }
}
