package com.teamvita.hotel.repo;
import com.teamvita.hotel.model.*;
import java.util.List;

public class ReservaDAO {
    public Reserva getReserva(int idReserva) { return null; }
    public void actualizarReserva(Reserva reserva) {}
    public void guardarReserva(Reserva reserva) {}
}
