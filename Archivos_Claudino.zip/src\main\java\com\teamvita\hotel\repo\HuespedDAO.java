package com.teamvita.hotel.repo;
import com.teamvita.hotel.model.*;
import java.util.List;

public class HuespedDAO {
    public Huesped obtenerORegistrarHuesped(Object datosHuesped) { return null; }
}
