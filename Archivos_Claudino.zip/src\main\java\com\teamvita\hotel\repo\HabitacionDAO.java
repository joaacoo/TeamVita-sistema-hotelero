package com.teamvita.hotel.repo;
import com.teamvita.hotel.model.*;
import java.util.List;

public class HabitacionDAO {
    public void marcarNoDisponible(Habitacion habitacion) {}
    public boolean verificarDisponibilidad(List<Habitacion> habitaciones, Object fechas) { return false; }
}
