package com.teamvita.hotel.repo;
import com.teamvita.hotel.model.*;
import java.util.List;

public class FacturaDAO {
    public void guardarFactura(Factura factura) {}
}
